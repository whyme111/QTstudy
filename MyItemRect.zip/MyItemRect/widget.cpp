﻿#include "widget.h"
#include "ui_widget.h"
#include"QGraphicsScene"
#include"myrect.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QGraphicsScene* Myscene=new QGraphicsScene;
    MyRect* Temp=new MyRect();
    Myscene->addItem(Temp);
    Temp->setPos(0,0);
    Myscene->setSceneRect(-2000,-2000,4000,4000);
    connect(Temp,&MyRect::UpdateMyscene,this,&Widget::UpdateMyscene);
	//不要问这个矩阵。
    QMatrix RotateMatrix = QMatrix(0, -1, -1, 0, 0, 0);
    ui->graphicsView->setMatrix(RotateMatrix);
    ui->graphicsView->setScene(Myscene);
    ui->graphicsView->update();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::UpdateMyscene()
{
	QGraphicsScene* Myscene = ui->graphicsView->scene();
	Myscene->update();
}

