﻿#ifndef MYRECT_H
#define MYRECT_H

#include <QObject>
#include"qgraphicsitem.h"
#include"qcursor.h"
#include<QGraphicsSceneMouseEvent>
class MyRect :public QObject,public QGraphicsItem
{
    Q_OBJECT//我偷懒不想写太多的类，鼠标事件没穿透，然后就用信号槽了=。=  目的在于刷新scene，否则会有残影。可以注释我的信号槽看看效果

public:
    MyRect();
    //这里我为了方便将变量放在了Public
    double _head=100;//头部
    double _width=200;//宽度
    double _tail=100;//尾部
signals:
    void UpdateMyscene();

protected:
    QRectF boundingRect()const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    QPainterPath shape()const;

    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    void hoverMoveEvent(QGraphicsSceneHoverEvent *event);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

private:
    void ResetRect(QRectF rect);
    bool cScale;//是否可以进行变换
    QRectF m_rect;
    bool If_hover;//是否触发hover
    QCursor* m_cursor;
    QPointF start;
    QPointF end;
    int direction=0;
};

#endif // MYRECT_H
