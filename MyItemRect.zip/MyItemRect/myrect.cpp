﻿#include "myrect.h"
#include<QPainter>
#include<math.h>
#include"qdebug.h"
MyRect::MyRect()
{
    setFlags(ItemIsSelectable);
    setAcceptHoverEvents(true);
    m_cursor = new QCursor;
    direction = 0;
    If_hover = false;
	//不要问我为什么用这个矩阵，问就是蛋疼
    //如果你们删了这个矩阵，需要自行修改参数，哈哈哈，当然找我修改也行呀~
    QMatrix RotateMatrix = QMatrix(0, -1, -1, 0, 0, 0);
    this->setMatrix(RotateMatrix);
    m_rect = QRectF(-_width / 2, -_head, _width, _head + _tail);

}

QRectF MyRect::boundingRect() const
{
   //没错，这句代码效果和m_rect.adjusted(-add, -add, add, add)一样。add=10
	return QRectF(m_rect.x() - 10, m_rect.y() - 10, m_rect.width() + 20, m_rect.height() + 20);
}

void MyRect::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(option);
    Q_UNUSED(widget);
    QRectF tempRec = m_rect;
    painter->setBrush(QBrush(Qt::green));
    QPen mypen;
    if (If_hover)
    {
        mypen = QPen(Qt::black, 3);
    }
    else
    {
        mypen = QPen(Qt::blue, 1);
    }
    painter->setPen(mypen);

    painter->drawRect(tempRec);
	painter->setBrush(Qt::NoBrush);
	mypen = QPen(Qt::blue, 2);
	painter->setPen(mypen);
}

QPainterPath MyRect::shape() const
{
    qreal add = 5;
    QPainterPath path;	
    path.addRect(m_rect.adjusted(-add, -add, add, add));
    return path;
}

void MyRect::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
            start = event->scenePos();
            cScale = true;
        }
        update();
        QGraphicsItem::mousePressEvent(event);
}

void MyRect::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
	
	if (cScale)
    {
		
		QPointF dis;
            end = event->scenePos();
            switch (direction) {
            case 1:
            {
                if (end.x() <= 0)
                {
                    QRectF tem = QRectF(m_rect.x(), event->scenePos().x(), m_rect.width(), _tail - event->scenePos().x());
                    this->ResetRect(tem);

                }
                else
                {
                    QRectF tem = QRectF(m_rect.x(), -event->scenePos().x(), m_rect.width(), event->scenePos().x() + _tail);
                    this->ResetRect(tem);               
                }              
                break;
            }
            case 2:
            {
                if (end.y() > 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(-end.y(), end.x(), 2 * end.y(), _tail - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(end.y(), end.x(), -2 * end.y(), _tail - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(end.y(), -end.x(), -2 * end.y(), _tail + end.x());
                    this->ResetRect(tem);
                }
                if (end.y() > 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(-end.y(), -end.x(), 2 * end.y(), _tail + end.x());
                    this->ResetRect(tem);
                }
                break;
            }
            case 3:
            {
                if (end.y() >= 0)
                {
                    QRectF tem = QRectF(-end.y() , m_rect.y(), 2*end.y() , m_rect.height());
                    this->ResetRect(tem);
                }
                else//采用鼠标最终位置
                {
                    QRectF tem = QRectF(end.y(), m_rect.y(), -2*end.y(), m_rect.height());
                    this->ResetRect(tem);
                }
                break;
            }
            case 4:
            {
                if (end.y() > 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(-end.y(), -_head, 2 * end.y(), _head - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(end.y(), -_head, -2 * end.y(), _head - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(end.y(), -_head, -2 * end.y(), _head + end.x());
                    this->ResetRect(tem);
                }
                if (end.y() > 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(-end.y(), -_head, 2 * end.y(), _head + end.x());
                    this->ResetRect(tem);
                }
                break;
            }
            case 5:
            {
                if (end.x() >= 0)
                {
                    QRectF tem = QRectF(m_rect.x(), -_head, m_rect.width(), _head + event->scenePos().x());
                    this->ResetRect(tem);
                }
                else
                {
                    QRectF tem = QRectF(m_rect.x(), -_head, m_rect.width(), _head- event->scenePos().x());
                    this->ResetRect(tem);
                }
                break;

            }
            case 6:
            {
                if (end.y() > 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(-end.y(), -_head, 2 * end.y(), _head - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(end.y(), -_head, -2 * end.y(), _head - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(end.y(), -_head, -2 * end.y(), _head + end.x());
                    this->ResetRect(tem);
                }
                if (end.y() > 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(-end.y(), -_head, 2 * end.y(), _head + end.x());
                    this->ResetRect(tem);
                }
                break;
            }
            case 7:
            {
                if (end.y() <= 0)
                {
                    QRectF tem = QRectF(end.y(), m_rect.y(), -2 * end.y(), m_rect.height());
                    this->ResetRect(tem);
                }
                else
                {
                    QRectF tem = QRectF(-end.y(), m_rect.y(), 2 * end.y(), m_rect.height());
                    this->ResetRect(tem);
                }
                break;
            }
            case 8:
            {
                if (end.y() > 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(-end.y(), end.x(), 2 * end.y(), _tail - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() < 0)
                {
                    QRectF tem = QRectF(end.y(), end.x(), -2 * end.y(), _tail - end.x());
                    this->ResetRect(tem);
                }
                if (end.y() < 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(end.y(), -end.x(), -2 * end.y(), _tail + end.x());
                    this->ResetRect(tem);
                }
                if (end.y() > 0 && end.x() > 0)
                {
                    QRectF tem = QRectF(-end.y(), -end.x(), 2 * end.y(), _tail + end.x());
                    this->ResetRect(tem);
                }
                break;

            }
            }
        }

            _head = abs(m_rect.top());
            _tail =abs( m_rect.bottom());
            _width = m_rect.width();
			
			QGraphicsItem::mouseMoveEvent(event);
			emit(UpdateMyscene());//我发射了信号！不用这个的话请在自己写的scene里面调用update。   
			
}

void MyRect::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    cScale = false;
    update();
    QGraphicsItem::mouseReleaseEvent(event);
	

}

void MyRect::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    If_hover = true;

        QPointF pos1 = event->scenePos();
        QPointF lt = this->scenePos() + QPointF(_head, m_rect.width() / 2);
        QPointF lb = this->scenePos() + QPointF( - _tail, m_rect.width() / 2);
        QPointF rt = this->scenePos() + QPointF(_head, -m_rect.width() / 2);
        QPointF rb = this->scenePos() + QPointF(-_tail, -m_rect.width() / 2);
        if ((pos1.x() >= lt.x() - 2 && pos1.y() >= lt.y() - 2)
            || (pos1.x() <= rb.x() + 2 && pos1.y() <= rb.y() + 2)) {
            m_cursor->setShape(Qt::SizeFDiagCursor);
            if (pos1.x() >= lt.x() - 2)direction = 8;
            else direction = 4;
        }
        else if ((pos1.x() <= lb.x() + 2 && pos1.y() >= lb.y() - 2)
            || (pos1.x() >= rt.x() - 2 && pos1.y() <= rt.y() + 2)) {
            m_cursor->setShape(Qt::SizeBDiagCursor);
            if (pos1.x() <= lb.x() + 2)direction = 6;
            else direction = 2;
        }
        else if ((pos1.y() >= lt.y() - 2 || pos1.y() <= rt.y() + 2)
            && (pos1.x() <= lt.x() && pos1.x() >= lb.x())) {
            m_cursor->setShape(Qt::SizeHorCursor);
            if (pos1.y() >= lt.y() - 2)direction = 7;
            else direction = 3;
        }
        else if ((pos1.x() >= lt.x() - 2 || pos1.x() <= lb.x() + 2)
            && (pos1.y() >= rt.y() && pos1.y() <= lt.y())) {
            m_cursor->setShape(Qt::SizeVerCursor);
            if (pos1.x() >= lt.x() - 2)direction = 1;
            else direction = 5;
        }
        else {
            cScale = false;
            direction = 0;
            m_cursor->setShape(Qt::ArrowCursor);
        }
        this->setCursor(*m_cursor);
        update();
        QGraphicsItem::hoverEnterEvent(event);
}

void MyRect::hoverMoveEvent(QGraphicsSceneHoverEvent *event)
{
        QPointF pos1 = event->scenePos();
        QPointF lt = this->scenePos() + QPointF(_head, m_rect.width() / 2);
        QPointF lb = this->scenePos() + QPointF(-_tail, m_rect.width() / 2);
        QPointF rt = this->scenePos() + QPointF(_head, -m_rect.width() / 2);
        QPointF rb = this->scenePos() + QPointF(-_tail, -m_rect.width() / 2);
        if ((pos1.x() >= lt.x() - 2 && pos1.y() >= lt.y() - 2)
            || (pos1.x() <= rb.x() + 2 && pos1.y() <= rb.y() + 2)) {
            m_cursor->setShape(Qt::SizeFDiagCursor);
            if (pos1.x() >= lt.x() - 2)direction = 8;
            else direction = 4;
        }
        else if ((pos1.x() <= lb.x() + 2 && pos1.y() >= lb.y() - 2)
            || (pos1.x() >= rt.x() - 2 && pos1.y() <= rt.y() + 2)) {
            m_cursor->setShape(Qt::SizeBDiagCursor);
            if (pos1.x() <= lb.x() + 2)direction = 6;
            else direction = 2;
        }
        else if ((pos1.y() >= lt.y() - 2 || pos1.y() <= rt.y() + 2)
            && (pos1.x() <= lt.x() && pos1.x() >= lb.x())) {
            m_cursor->setShape(Qt::SizeHorCursor);
            if (pos1.y() >= lt.y() - 2)direction = 7;
            else direction = 3;
        }
        else if ((pos1.x() >= lt.x() - 2 || pos1.x() <= lb.x() + 2)
            && (pos1.y() >= rt.y() && pos1.y() <= lt.y())) {
            m_cursor->setShape(Qt::SizeVerCursor);
            if (pos1.x() >= lt.x() - 2)direction = 1;
            else direction = 5;
        }
        else {
            cScale = false;
            direction = 0;
            m_cursor->setShape(Qt::ArrowCursor);
        }
        this->setCursor(*m_cursor);
        update();
        QGraphicsItem::hoverMoveEvent(event);
}

void MyRect::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    direction = 0;
        If_hover = false;
        m_cursor->setShape(Qt::ArrowCursor);
        cScale = false;
        this->setCursor(*m_cursor);
        update();
        QGraphicsItem::hoverLeaveEvent(event);
}

void MyRect::ResetRect(QRectF rect)
{
    m_rect = rect;
    update();
}
